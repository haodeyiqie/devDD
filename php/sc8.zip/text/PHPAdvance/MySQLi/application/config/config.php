<?php
$config = array(
    'host'=>'localhost',
    'user'=>'root',
    'password'=>'root',
    'charset'=>'utf8',
    'dbName'=>'51zxw'
);


define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PWD','root');
define('DB_CHARSET','utf8');
define('DB_DBNAME','51zxw');