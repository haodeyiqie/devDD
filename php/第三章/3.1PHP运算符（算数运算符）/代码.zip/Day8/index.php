<?php




echo __LINE__;
echo '<hr/>';
echo __FILE__;
echo '<hr/>';
echo __DIR__;