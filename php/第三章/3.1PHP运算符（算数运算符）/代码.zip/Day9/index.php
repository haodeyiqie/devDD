<?php
// $rand = mt_rand(1000, 9999);
$code = '<span style="color:rgb('.mt_rand(0, 255).','.mt_rand(0, 255).'
    ,'.mt_rand(0, 255).')">'.mt_rand(0, 9).'</span>';
echo $code;