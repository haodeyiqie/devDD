<?php
   $a=1+"13abc9c";
   echo $a;
?>





