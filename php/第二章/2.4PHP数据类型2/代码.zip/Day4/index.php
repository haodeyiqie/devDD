<?php
   $handle = fopen('text.php', 'r');
   echo $handle;