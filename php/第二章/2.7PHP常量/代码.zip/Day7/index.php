<?php
    echo PHP_VERSION;
    echo '<hr/>';
    echo PHP_OS;
    echo '<hr/>';
    echo M_PI;
    echo '<hr/>';
    define('CLIVE', '��˧��');
    echo CLIVE;
    echo '<hr/>';
    const ZXW = '��Ҫ��ѧ��';
    echo ZXW;
    echo '<hr/>';
   echo constant('ZXW');
   echo '<hr/>';
   var_dump(defined('С��'));