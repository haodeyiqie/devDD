<?php
   $a = 123.2;
  var_dump(is_int($a));